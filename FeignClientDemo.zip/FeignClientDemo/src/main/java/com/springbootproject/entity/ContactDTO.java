package com.springbootproject.entity;



public class ContactDTO {
	private int id;
	private int uid;
	private String contactNumber;
	
	public ContactDTO() {}
	public ContactDTO(int id, int uid, String contactNumber) {
		super();
		this.id = id;
		this.uid = uid;
		this.contactNumber = contactNumber;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	@Override
	public String toString() {
		return "ContactDTO [id=" + id + ", uid=" + uid + ", contactNumber=" + contactNumber + "]";
	}
	
	
	
	
}
