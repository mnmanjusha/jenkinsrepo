package com.springbootproject.entity;

import java.util.List;

public class Users {
	private int id;
	private String uname;
	private String add;
	
	//private List <Contact> contactList;
	
	public Users() {}

	public Users(int id, String uname, String add/* , List <Contact> contactList */) {
		super();
		this.id = id;
		this.uname = uname;
		this.add = add;
		//this.contactList=contactList;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}

	/*
	 * public List<Contact> getContactList() { return contactList; } public void
	 * setContactList(List<Contact> contactList) { this.contactList = contactList; }
	 */	@Override
	public String toString() {
		return "Users [id=" + id + ", uname=" + uname + ", add=" + add +  "]";
	}
	
}
