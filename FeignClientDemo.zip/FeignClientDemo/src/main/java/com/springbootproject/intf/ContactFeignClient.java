package com.springbootproject.intf;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.springbootproject.entity.Contact;

@FeignClient(name="CONTACT-SERVICE" , url="http://localhost:9001/contact")
public interface ContactFeignClient {

	@PostMapping("/addcontact")
	public ResponseEntity<String> addContact(Contact contact);
	
	@GetMapping("/getallcontacts")
	public List<Contact> getAll();

	@GetMapping("/getbyuid/{uid}")
	public List<Contact> getByUid(@PathVariable("uid") int uid);
	
}
