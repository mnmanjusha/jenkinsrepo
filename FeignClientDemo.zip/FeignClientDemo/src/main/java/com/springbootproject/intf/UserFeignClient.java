package com.springbootproject.intf;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.springbootproject.entity.UserDTO;
import com.springbootproject.entity.Users;

@FeignClient(name="USER-SERVICE" , url="http://localhost:9001/users")
public interface UserFeignClient {

	@PostMapping("/adduser")
	public ResponseEntity<String> addUser(Users user);
	
	@GetMapping("/getallusers")
	public List<Users> getAll();
	
	@GetMapping("/getbyuid/{id}")
	public UserDTO getByUid(@PathVariable("id") int uid);
}
