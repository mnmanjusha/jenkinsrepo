package com.springbootproject.controller;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springbootproject.entity.Contact;
import com.springbootproject.entity.ContactDTO;
import com.springbootproject.entity.UserDTO;
import com.springbootproject.entity.Users;
import com.springbootproject.intf.ContactFeignClient;
import com.springbootproject.intf.UserFeignClient;

@RestController
public class UserFeignController {

	@Autowired
	private UserFeignClient userClient;
	
	@Autowired
	private ContactFeignClient contactClient;
	
	@Autowired
	private ModelMapper mapper;
	
	@PostMapping("/add")
	public ResponseEntity<String> addUser(@RequestBody UserDTO user){
		Users users=mapper.map(user, Users.class);
		return userClient.addUser(users);
	}
	
	@GetMapping("/getall")
	public List<Users> getAllUsers(){
		
		return userClient.getAll();
	}
	
	@GetMapping("/getbyuid/{id}")
	public UserDTO getbyuid(@PathVariable("id") int uid) {
		UserDTO user=userClient.getByUid(uid);
				
		ContactDTO cdto=null;
		
		List<Contact> clist=contactClient.getByUid(uid);
		List <ContactDTO> cdtoList=new ArrayList<>();
		
		for(Contact c : clist) {
			 cdto=mapper.map(c, ContactDTO.class);
			 cdtoList.add(cdto);
		}
		
		user.setClist(cdtoList);
		
		return user;
	}
	
	@GetMapping("/getallcontacts")
	public List<Contact> getAllContacts(){
		return contactClient.getAll();
	}
}
