package com.springbootproject.service;

import java.util.List;

import jakarta.persistence.Column;

public class UserDTO {
	
	private int id;
	private String uname;
	private String add;
	
	//private List<ContactDTO> clist;

	public UserDTO() {}
	public UserDTO(int id, String uname, String add, List<ContactDTO> clist) {
		super();
		this.id = id;
		this.uname = uname;
		this.add = add;
	//	this.clist = clist;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}

	/*
	 * public List<ContactDTO> getClist() { return clist; } public void
	 * setClist(List<ContactDTO> clist) { this.clist = clist; }
	 */
	@Override
	public String toString() {
		return "UserDTO [id=" + id + ", uname=" + uname + ", add=" + add /* + ", clist=" + clist */+ "]";
	}
}
