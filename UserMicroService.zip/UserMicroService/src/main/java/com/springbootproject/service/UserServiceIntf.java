package com.springbootproject.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.springbootproject.entity.Users;

public interface UserServiceIntf {
    public ResponseEntity<String> addUser(Users user);
    public List<Users> getAll();
    public Users getByUserId(int id);
    
}
