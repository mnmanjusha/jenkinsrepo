package com.springbootproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.springbootproject.entity.Users;
import com.springbootproject.repository.UserRepository;

@Component
public class UsersService implements UserServiceIntf{

	@Autowired
	private UserRepository urepository;
	
	public ResponseEntity<String> addUser(Users user) {
		
		urepository.save(user);
		return new ResponseEntity("User Added", HttpStatus.OK);
	}

	
	public List<Users> getAll() {
		// TODO Auto-generated method stub
		return urepository.findAll();
	}
	
	public Users getByUserId(int id) {
		// TODO Auto-generated method stub
	    return urepository.findById(id).get();
	}

}
