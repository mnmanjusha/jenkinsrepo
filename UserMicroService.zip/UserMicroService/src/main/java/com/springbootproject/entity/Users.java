package com.springbootproject.entity;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity
@Table(name="usertab")
public class Users {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	@Column(name="uname")
	private String uname;
	@Column(name="add")
	private String add;
	
	/*
	 * @Transient private List <Contact> contactList;
	 */	
	
	public Users() {}
	public Users(int id, String uname, String add) {
		super();
		this.id = id;
		this.uname = uname;
		this.add = add;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}
	@Override
	public String toString() {
		return "Users [id=" + id + ", uname=" + uname + ", add=" + add + "]";
	}
	
	
	
	
	
	
	
}
