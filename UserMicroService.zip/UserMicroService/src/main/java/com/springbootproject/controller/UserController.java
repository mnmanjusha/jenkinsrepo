package com.springbootproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springbootproject.entity.Users;

import com.springbootproject.service.UsersService;

@RestController
//@RequestMapping("/userapi")
public class UserController {

	@Autowired
	private UsersService uservice;
	
	@PostMapping("/adduser")
	public ResponseEntity<String> addUser(@RequestBody Users user){
		return uservice.addUser(user); 
	}
	
	@GetMapping("/getallusers")
	public List<Users> getAll(){
		
		return uservice.getAll();
	}
	
	@GetMapping("/getbyuid/{id}")
	public Users getByUid(@PathVariable("id") int id) {
		
		return uservice.getByUserId(id);
	}
}
