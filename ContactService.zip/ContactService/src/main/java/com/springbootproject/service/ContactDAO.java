package com.springbootproject.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.springbootproject.entity.Contact;

public interface ContactDAO {
    public ResponseEntity<String> addContact(Contact contact);
    public List<Contact> getAll();
    public List<ContactDTO> getByUid(int id);
}
