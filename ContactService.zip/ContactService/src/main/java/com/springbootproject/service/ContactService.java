package com.springbootproject.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.catalina.mapper.Mapper;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.springbootproject.entity.Contact;
import com.springbootproject.repository.ContactRepository;

@Component
public class ContactService implements ContactDAO{

	@Autowired
	private ContactRepository crepository;
	
	@Autowired 
	private ModelMapper mapper;
	
	public ResponseEntity<String> addContact(Contact contact) {
		
		crepository.save(contact);
		return new ResponseEntity("Contact Added", HttpStatus.OK);
	}

	
	public List<Contact> getAll() {
		// TODO Auto-generated method stub
		return crepository.findAll();
	}


	
	public List<ContactDTO> getByUid(int id) {
		// TODO Auto-generated method stub
		List<Contact> clist=crepository.findByUid(id);
		List<ContactDTO> cdtoList=new ArrayList<>();
		
		
		for(Contact c : clist) {
            ContactDTO cdto=mapper.map(c, ContactDTO.class);
            cdtoList.add(cdto);
		}
		
		return cdtoList;
	}

}
