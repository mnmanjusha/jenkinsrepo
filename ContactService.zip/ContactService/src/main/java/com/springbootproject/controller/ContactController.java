package com.springbootproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springbootproject.entity.Contact;
import com.springbootproject.service.ContactDTO;
import com.springbootproject.service.ContactService;

@RestController
//@RequestMapping("/contactapi")
public class ContactController {

	@Autowired
	private ContactService cservice;
	
	@PostMapping("/addcontact")
	public ResponseEntity<String> addContact(@RequestBody Contact contact){
		return cservice.addContact(contact); 
	}
	
	@GetMapping("/getallcontacts")
	public List<Contact> getAll(){
		System.out.println("Received");
		return cservice.getAll();
	}
	
	@GetMapping("/getbyuid/{uid}")
	public List<ContactDTO> getByUid(@PathVariable("uid") int uid){
		return cservice.getByUid(uid);
	}
}
