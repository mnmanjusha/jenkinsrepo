package com.springbootproject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.springbootproject.entity.Contact;

@Repository
public interface ContactRepository extends JpaRepository<Contact, Integer>{
    @Query("select c from Contact c where c.uid=:id")
	public List<Contact> findByUid(int id);
    
}
